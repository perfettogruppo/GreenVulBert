import math
import random
import subprocess
import time

import numpy as np
import pandas as pd
from torch.utils.data import Dataset, DataLoader
import torch
import torch.nn as nn
import torch.optim as optim
from tqdm import tqdm
from transformers import (
    AutoTokenizer,
    AutoModelForSequenceClassification,
    get_linear_schedule_with_warmup,
    BertModel,
    BertConfig
)
from sklearn.model_selection import train_test_split
from typing import List
import torch.nn.functional as F

# NEW: Additional metrics
from sklearn.metrics import (
    precision_recall_fscore_support,
    accuracy_score,
    cohen_kappa_score,
    mean_squared_error,
    mean_absolute_error
)

###############################################################################
# 4. Hyperparameters, Distillation Setup
###############################################################################
num_epochs = 10
batch_size = 8
learning_rate = 2e-5
max_length = 512
weight_decay = 0.01
alpha = 0.8
temperature = 3.0
patience = 11

teacher_model_path = "/home/leili/Vul/MSC-Group/bert_cvss/bert_cnn/combined50/SBert/models"
student_model_name = "sentence-transformers/all-MiniLM-L6-v2"
metrics = ["AV", "AC", "PR", "UI","C", "S", "I", "A"]


out_dir = "distilled_student_{metric}"

# For green-computing estimates
GPU_POWER_WATTS = 245.0       # Approx. GPU power usage for RTX 2080 Ti
EMISSION_FACTOR = 0.5         # kg CO2 per kWh (global average example)

###############################################################################
# 0. Fix Random Seed
###############################################################################
def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

set_seed(42)

###############################################################################
# 1. Read the CSV and map categorical columns to numeric values
###############################################################################
df = pd.read_csv('./data/combined.csv')

# Example mappings (adjust as needed):
df['av'] = df['av'].map({'N': 0, 'L': 1, 'A': 2, 'P': 3})
df['ac'] = df['ac'].map({'L': 0, 'H': 1})
df['pr'] = df['pr'].map({'L': 0, 'H': 1, 'N': 2})
df['ui'] = df['ui'].map({'R': 0, 'N': 1})
df['s'] = df['s'].map({'C': 0, 'U': 1})
df['c'] = df['c'].map({'H': 0, 'N': 1, 'L': 2})
df['i'] = df['i'].map({'H': 0, 'N': 1, 'L': 2})
df['a'] = df['a'].map({'H': 0, 'N': 1, 'L': 2})

###############################################################################
# GPU Selection by Memory
###############################################################################
def get_free_gpu():
    if not torch.cuda.is_available():
        return torch.device('cpu')
    nvidia_smi_output = subprocess.check_output(
        ["nvidia-smi", "--query-gpu=memory.used,memory.total", "--format=csv,nounits,noheader"]
    ).decode("utf-8")
    gpu_memory = nvidia_smi_output.strip().split("\n")
    memory_usage = []
    for i, gpu in enumerate(gpu_memory):
        used, total = map(int, gpu.split(','))
        memory_usage.append((i, used / total))  # usage ratio
    memory_usage = sorted(memory_usage, key=lambda x: x[1])
    best_gpu = memory_usage[0][0]
    return torch.device(f'cuda:{best_gpu}')

device = get_free_gpu()
if device.type == 'cuda':
    print(f'Using GPU: {torch.cuda.get_device_name(device.index)}')
else:
    print('Using CPU')

###############################################################################
# 2. Simple PyTorch Dataset
###############################################################################
class VulnerabilityDataset(Dataset):
    def __init__(self, texts: List[str], labels: List[int], tokenizer, max_length=128):
        self.texts = texts
        self.labels = labels
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        text = str(self.texts[idx])
        label = self.labels[idx]

        encoding = self.tokenizer(
            text,
            max_length=self.max_length,
            truncation=True,
            padding='max_length',
            return_tensors='pt'
        )
        item = {key: val.squeeze(0) for key, val in encoding.items()}
        item['labels'] = torch.tensor(label, dtype=torch.long)
        return item

###############################################################################
# 3. A Student Model Class
###############################################################################
class SBertForSequenceClassification(nn.Module):
    def __init__(self, model_name: str, num_labels: int):
        super().__init__()
        config = BertConfig.from_pretrained(model_name)
        config.num_labels = num_labels
        self.bert = BertModel.from_pretrained(model_name, config=config)
        self.classifier = nn.Linear(config.hidden_size, num_labels)

    def forward(self, input_ids, attention_mask, labels=None):
        outputs = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        pooled_output = outputs.pooler_output  # [batch_size, hidden_size]
        logits = self.classifier(pooled_output) # [batch_size, num_labels]
        loss = None
        if labels is not None:
            loss_fn = nn.CrossEntropyLoss()
            loss = loss_fn(logits, labels)

        return {
            'logits': logits,
            'loss': loss
        }
    def save_pretrained(self, save_directory):
        """
        Mimic the huggingface 'save_pretrained' logic:
          1) save self.bert via its huggingface save_pretrained
          2) save the classifier weights with torch.save
        """
        import os
        import torch

        # Create the directory if it doesn’t exist
        os.makedirs(save_directory, exist_ok=True)

        # 1) Save the underlying BERT
        self.bert.save_pretrained(save_directory)

        # 2) Save our classifier state dict
        torch.save(self.classifier.state_dict(), os.path.join(save_directory, "classifier.bin"))
###############################################################################
# Evaluate Helper (Precision, Recall, F1, Accuracy, Cohen Kappa, MSE, MAE)
###############################################################################
def evaluate_metrics(model, data_loader):
    """
    Returns precision, recall, f1, accuracy, cohen_kappa, mse, mae on data_loader.
    """
    model.eval()
    all_preds = []
    all_labels = []

    with torch.no_grad():
        for batch in data_loader:
            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)
            labels = batch["labels"].to(device)

            outputs = model(input_ids=input_ids, attention_mask=attention_mask)
            logits = outputs['logits']
            preds = torch.argmax(logits, dim=-1)

            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())

    precision, recall, f1, _ = precision_recall_fscore_support(
        all_labels, all_preds, average='weighted'
    )
    accuracy = accuracy_score(all_labels, all_preds)
    kappa = cohen_kappa_score(all_labels, all_preds)

    # MSE / MAE treat labels & predictions as numerical values
    mse = mean_squared_error(all_labels, all_preds)
    mae = mean_absolute_error(all_labels, all_preds)

    return precision, recall, f1, accuracy, kappa, mse, mae

###############################################################################
# 5. Training Loop with Distillation + Early Stopping + Metrics
###############################################################################
for metric in metrics:
    metric_lower = metric.lower()  # e.g., "av"

    # Ensure we only take valid numeric values
    unique_vals = {x for x in df[metric_lower].unique() if not math.isnan(x)}
    NUM_LABELS = len(unique_vals)

    print(f"\nTraining for metric = {metric}, which has {NUM_LABELS} labels.")

    # 1. Split Data
    train_texts, val_texts, train_labels, val_labels = train_test_split(
        df['text'], df[metric_lower], test_size=0.2, random_state=42
    )

    train_texts = train_texts.tolist()
    val_texts = val_texts.tolist()
    train_labels = train_labels.tolist()
    val_labels = val_labels.tolist()

    # 2. Load Teacher
    teacher_dir = f"{teacher_model_path}/{metric}"
    teacher_tokenizer = AutoTokenizer.from_pretrained("bert-base-cased")
    teacher_model = AutoModelForSequenceClassification.from_pretrained(
        teacher_dir,
        num_labels=NUM_LABELS
    ).to(device)
    teacher_model.eval()

    # 3. Load Student
    student_tokenizer = AutoTokenizer.from_pretrained(student_model_name)
    student_model = SBertForSequenceClassification(
        model_name=student_model_name,
        num_labels=NUM_LABELS
    ).to(device)

    # (Optional) Drop certain layers in the student model
    auto_model = student_model.bert
    layers_to_keep = [0, 2, 3, 5]
    new_layers = nn.ModuleList(
        [layer_module for i, layer_module in enumerate(auto_model.encoder.layer) if i in layers_to_keep]
    )
    auto_model.encoder.layer = new_layers
    auto_model.config.num_hidden_layers = len(layers_to_keep)

    # 4. Create Dataloaders
    train_dataset = VulnerabilityDataset(train_texts, train_labels, student_tokenizer, max_length=max_length)
    val_dataset = VulnerabilityDataset(val_texts, val_labels, student_tokenizer, max_length=max_length)

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)

    # 5. Define Optimizer & Scheduler
    optimizer = optim.AdamW(student_model.parameters(), lr=learning_rate, weight_decay=weight_decay)
    num_training_steps = num_epochs * len(train_loader)
    scheduler = get_linear_schedule_with_warmup(
        optimizer,
        num_warmup_steps=0,
        num_training_steps=num_training_steps
    )

    # 6. Distillation + CE Training Variables
    best_accuracy = 0.0
    epochs_no_improve = 0
    kl_div_loss_fn = nn.KLDivLoss(reduction='batchmean')

    # Track all epoch metrics here
    epoch_results = []

    # Track total training start time
    train_start_time = time.time()

    # 7. Distillation Loop
    for epoch in range(num_epochs):
        epoch_start_time = time.time()
        student_model.train()
        total_loss = 0.0

        for step, batch in enumerate(tqdm(train_loader, desc=f"{metric} Distillation Epoch {epoch + 1}/{num_epochs}")):
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            labels = batch['labels'].to(device)

            # (a) Student forward pass
            student_outputs = student_model(
                input_ids=input_ids,
                attention_mask=attention_mask,
                labels=labels
            )
            student_logits = student_outputs['logits']
            ce_loss = student_outputs['loss']  # Cross-entropy with ground truth

            # (b) Teacher logits (no grad)
            with torch.no_grad():
                teacher_outputs = teacher_model(
                    input_ids=input_ids,
                    attention_mask=attention_mask
                )
                teacher_logits = teacher_outputs.logits

            # (c) Distillation Loss with Temperature
            teacher_probs = F.softmax(teacher_logits / temperature, dim=-1)
            student_log_probs = F.log_softmax(student_logits / temperature, dim=-1)
            kd_loss = kl_div_loss_fn(student_log_probs, teacher_probs) * (temperature ** 2)

            # (d) Combine CE Loss + KD Loss
            loss = (1 - alpha) * ce_loss + alpha * kd_loss

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            scheduler.step()

            total_loss += loss.item()

        # Compute average train loss
        avg_train_loss = total_loss / len(train_loader)

        # Validation metrics
        precision, recall, f1, accuracy, kappa, mse, mae = evaluate_metrics(student_model, val_loader)

        epoch_time = time.time() - epoch_start_time

        print(
            f"Epoch {epoch+1}/{num_epochs} - "
            f"Train Loss: {avg_train_loss:.4f}, "
            f"Val Acc: {accuracy:.4f}, "
            f"Val Precision: {precision:.4f}, Val Recall: {recall:.4f}, Val F1: {f1:.4f}, "
            f"Kappa: {kappa:.4f}, MSE: {mse:.4f}, MAE: {mae:.4f}, "
            f"Time: {epoch_time:.2f}s"
        )

        # Save the epoch results
        epoch_results.append({
            "epoch": epoch + 1,
            "train_loss": avg_train_loss,
            "precision": precision,
            "recall": recall,
            "f1_score": f1,
            "accuracy": accuracy,
            "cohen_kappa": kappa,
            "mse": mse,
            "mae": mae,
            "epoch_time_s": epoch_time
        })

        # Early Stopping Check
        if accuracy > best_accuracy:
            best_accuracy = accuracy
            epochs_no_improve = 0
        else:
            epochs_no_improve += 1
        if epochs_no_improve >= patience:
            print(f"No improvement for {patience} epochs. Stopping early.")
            break

    # -------------------------------------------
    #  After all epochs -> total training time
    # -------------------------------------------
    train_end_time = time.time()
    total_train_time_s = train_end_time - train_start_time
    total_train_time_h = total_train_time_s / 3600.0

    # Estimate GPU energy usage (in Wh, then kWh)
    energy_used_Wh = GPU_POWER_WATTS * total_train_time_h * 1.0  # Only counting GPU
    energy_used_kWh = energy_used_Wh / 1000.0

    # Estimate CO2 (in kg)
    co2_emissions = energy_used_kWh * EMISSION_FACTOR

    # -------------------------------------------
    #  Measure inference time after training
    # -------------------------------------------
    # For demonstration, we measure on the validation set
    inference_start = time.time()

    student_model.eval()
    with torch.no_grad():
        for batch in val_loader:
            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)
            _ = student_model(input_ids=input_ids, attention_mask=attention_mask)

    inference_end = time.time()
    inference_time_s = inference_end - inference_start

    # Print final "green" metrics
    print(f"Total training time: {total_train_time_s:.2f} s")
    print(f"Inference time (val set): {inference_time_s:.4f} s")
    print(f"Estimated energy used: {energy_used_kWh:.4f} kWh")
    print(f"Estimated CO2 emissions: {co2_emissions:.4f} kg")

    # Save the Student Model
    final_out_dir = out_dir.format(metric=metric)
    student_model.cpu()
    student_model.save_pretrained(final_out_dir)
    student_tokenizer.save_pretrained(final_out_dir)
    print(f"Distilled student model saved to: {final_out_dir}")

    # -------------------------------------------
    #  Store final row with total training time,
    #  inference time, energy, CO2, etc.
    # -------------------------------------------
    final_metrics = {
        "epoch": "final",
        "train_time_s": total_train_time_s,
        "inference_time_s": inference_time_s,
        "energy_used_kWh": energy_used_kWh,
        "CO2_kg": co2_emissions
    }
    epoch_results.append(final_metrics)

    # Save epoch metrics + final row to CSV
    metrics_df = pd.DataFrame(epoch_results)
    metrics_csv_path = f"{final_out_dir}/training_metrics_{metric}.csv"
    metrics_df.to_csv(metrics_csv_path, index=False)

    print(f"Training (and final) metrics saved to: {metrics_csv_path}")
